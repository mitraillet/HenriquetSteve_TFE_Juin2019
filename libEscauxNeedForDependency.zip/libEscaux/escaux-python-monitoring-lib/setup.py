#!/usr/bin/env python
# coding: utf-8

from setuptools import setup, find_packages

setup(
	name="escauxmonitoring",
	version="1.1.0",
	description='Escaux Python Monitoring Library',

	test_suite='tests',

	# simple to run
	entry_points={
	},

	author='Sebastien De Fauw',
	author_email="sfa@escaux.com",

	packages=find_packages(exclude=('tests', 'docs')),

	include_package_data=True,  # include data from MANIFEST.in

	download_url=(""),

	test_requires=[
		'prometheus_client',
		'requests'
	],

	install_requires=[
		'escauxlib',
		'elasticsearch',
		'prometheus_client',
	],

)
