#!/usr/bin/env python
# coding: utf-8
from abc import abstractmethod


class Connector:

	@abstractmethod
	def __init__(self):
		pass


	@abstractmethod
	def push(self, data):
		raise Exception("Need to be implemented")