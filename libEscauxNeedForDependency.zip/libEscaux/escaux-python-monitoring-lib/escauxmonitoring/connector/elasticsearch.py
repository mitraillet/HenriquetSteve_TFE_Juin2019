#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

import datetime

from escauxmonitoring.connector import Connector

from elasticsearch import Elasticsearch


class ElasticConnector(Connector):

	def __init__(self, doc_type, index, server_host='127.0.0.1', server_port=9200):
		Connector.__init__(self)
		self.es = Elasticsearch("{}:{}".format(server_host, server_port))
		self.index_name = index
		self.doc_type = doc_type
		self.index = None
		self.id = None

	def push(self, data):
		if not self.index:
			self.index = self.index_name.format(datetime.datetime.now()) if "{" in self.index_name else self.index_name
			r = self.es.index(
				index=self.index,
				doc_type=self.doc_type,
				body=data
			)
			self.id = r['_id']
			return
		self.es.update(
			index=self.index,
			doc_type=self.doc_type,
			id=self.id,
			body=dict(doc=data)
		)


esc = None