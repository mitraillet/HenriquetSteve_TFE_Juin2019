#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

from escauxmonitoring.connector import Connector

from prometheus_client import start_http_server, Gauge, Counter, Summary, Histogram

import escauxlib.log as log

DEFAULT_BUCKETS = (.005, .01, .025, .05, .075, .1, .25, .5, .75, 1.0, 2.5, 5.0, 7.5, 10.0, float("+inf"))

class PrometheusConnector(Connector):

	def __init__(self, struct, tag, server_port=8000, server_addr=''):
		"""
		Initialize a prometheus exporter in order to push data

		The name MUST adhere to the Prometheus name guidelines (https://prometheus.io/docs/practices/naming/).

		:param struct: [
			dict(name="test", descr="Description of Test", unit="sec" tags=["my_tag"], type="gauge"),
			dict(name="test2_total", descr="Description of Test 2", tags=["my_tag"], type="counter")
			...
		]
		:param tag				Prometheus suffix
		:param server_port		Prometheus exporter port number
		:param buckets          Prometheus buckets (optional, if type is histogram)
		"""
		Connector.__init__(self)
		start_http_server(server_port, server_addr)
		self.metrics_list = dict()
		for item in struct:
			metric = None
			metric_name = '{suffix}_{name}{unit}'.format(suffix=tag, name=item['name'], unit='_' + item['unit'] if 'unit' in item else '')
			metric_descr = item['descr']
			metric_tags = item['tags'] if 'tags' in item else None

			if 'type' not in item or item['type'] == 'gauge':
				metric = Gauge(
					metric_name,
					metric_descr,
					metric_tags
				)
			elif item['type'] == 'counter':
				metric = Counter(
					metric_name,
					metric_descr,
					metric_tags
				)
			elif item['type'] == 'summary':
				metric = Summary(
					metric_name,
					metric_descr,
					metric_tags
				)
			elif item['type'] == 'histogram':
				metric = Histogram(
					metric_name,
					metric_descr,
					metric_tags,
					buckets=item['buckets'] if 'buckets' in item else DEFAULT_BUCKETS
				)
			else:
				log.error('Invalid metric type')

			self.metrics_list[item['name']] = metric

	def push(self, data):
		"""
			Update one or several prometheus metric(s)
			:param struct: dict({
				"test": dict(labels=["my_label"], value=-2),
				"test2_total": [dict(labels=["my_label"], value=2), dict(labels=["my_second_label"], value=3)]
			})
		"""
		for name, value in data.iteritems():
			if name not in self.metrics_list:
				log.warning("Incomplete schema: {}".format(name))
				continue
			metric = self.metrics_list[name]

			def set(value):
				if isinstance(value, dict):
					val = value['value']
				else:
					val = value

				if not val:
					# TODO maybe a better way to do that: unregister the metric object
					val = 0.0
				if not isinstance(val, (int, long, float)):
					log.error("{}: Invalid instance type for 'value'".format(name))
					return
				
				m = None
				if isinstance(value, dict):
					m = metric.labels(*value['labels'])
				else:
					m = metric

				if metric._type == "gauge":
					m.set(val)
				elif metric._type == "counter":
					if val < 0:
						log.error("{}: Invalid negative value".format(name))
						return
					m.inc(val)
				elif metric._type == "summary" or metric._type == "histogram":
					m.observe(val)
				else:
					log.error("{}: Unknown metric type.".format(name))

			if isinstance(value, list):
				for val in value:
					set(val)
			else:
				set(value)
