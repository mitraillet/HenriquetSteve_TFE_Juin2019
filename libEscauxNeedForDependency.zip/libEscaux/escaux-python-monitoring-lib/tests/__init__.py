#!/usr/bin/env python
# coding: utf-8

import unittest
import requests
import uuid
import time

import escauxmonitoring.connector.prometheus as prometheus
from prometheus_client.parser import text_string_to_metric_families

SERVER_ADDRESS = '127.0.58.5'
FIRST_PORT = 10300
n_ports = 0

class SchemaTestCase(unittest.TestCase):
	@classmethod
	def setUpClass(self):
		global n_ports

		SCHEMA = [
			{
				'name': 'first_metric',
				'unit': 'sec',
				'descr': 'First metric (in seconds)',
				'tags': ['tag_1', 'tag_2'],
				'type': 'gauge'
			},
			{
				'name': 'second_metric_ms',
				'descr': 'Second metric (in milliseconds), unit in name',
				'type': 'counter'
			},
			{
				'name': 'third_metric',
				'unit': 'm',
				'descr': 'Third metric (in meters)',
				'tags': ['tag_3'],
				'type': 'histogram'
			},
		]

		self.port = FIRST_PORT + n_ports
		n_ports += 1
		self.uuid = uuid.uuid4().get_hex()
		self.connector = prometheus.PrometheusConnector(SCHEMA, 'monitoring_lib_test_' + self.uuid, self.port, SERVER_ADDRESS)
	
	def test_metrics_created(self):
		families_found = {
			'monitoring_lib_test_{}_first_metric_sec'.format(self.uuid): False,
			'monitoring_lib_test_{}_second_metric_ms'.format(self.uuid): False,
			'monitoring_lib_test_{}_third_metric_m'.format(self.uuid): False,
		}

		r = requests.get('http://{address}:{port}'.format(address=SERVER_ADDRESS, port=self.port))
		self.assertEquals(r.status_code, 200)
		for family in text_string_to_metric_families(r.text):
			if family.name in families_found:
				families_found[family.name] = True

		for _, found in families_found.iteritems():
			self.assertEquals(found, True)

	def test_push(self):
		self.connector.push({
			'first_metric': [
				{
					'labels': ('value_1', 'value_2'),
					'value': 5.0
				},
				{
					'labels': ('value_3', 'value_4'),
					'value': 6.0
				}
			],
			'second_metric_ms': 7.0,
			'third_metric': {
				'labels': ('value_5',),
				'value': 8.0
			}
		})

		r = requests.get('http://{address}:{port}'.format(address=SERVER_ADDRESS, port=self.port))
		self.assertEquals(r.status_code, 200)
		for family in text_string_to_metric_families(r.text):
			if family.name == 'monitoring_lib_test_{}_first_metric_sec'.format(self.uuid):
				self.assertEquals(len(family.samples), 2)
				for sample in family.samples:
					self.assertTrue(sample[2] == 5.0 and {
						'tag_1': 'value_1',
						'tag_2': 'value_2'
					} or sample[2] == 6.0 and sample[1] == {
						'tag_1': 'value_3',
						'tag_2': 'value_4'
					})
			if family.name == 'monitoring_lib_test_{}_second_metric_ms'.format(self.uuid):
				self.assertEquals(len(family.samples), 1)
				self.assertEquals(family.samples[0][2], 7.0)
		# Not testing third metric because it is a histogram and generated dynamically