#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

import logging
import logging.handlers

BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)

# The background is set with 40 plus the number of the color, and the foreground with 30

# These are the sequences need to get colored ouput
RESET_SEQ = "\033[0m"
COLOR_SEQ = "\033[1;%dm"
BOLD_SEQ = "\033[1m"

level = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL
}

verbose_levels = {
    0: "WARNING",
    1: "INFO",
    2: "DEBUG"
}

log_level = 'WARNING'


def formatter_message(message, use_color=True):
    if use_color:
        message = message.replace("$RESET", RESET_SEQ).replace("$BOLD", BOLD_SEQ)
    else:
        message = message.replace("$RESET", "").replace("$BOLD", "")
    return message


COLORS = {
    'WARNING': YELLOW,
    'INFO': GREEN,
    'DEBUG': BLUE,
    'CRITICAL': MAGENTA,
    'ERROR': RED
}

DISPLAY_FORMAT = "%(levelname)-1s %(message)s"
LOG_FORMAT = "%(asctime)s %(levelno)s %(message)s"


class ColoredFormatter(logging.Formatter):
    def __init__(self, msg, use_color=True):
        logging.Formatter.__init__(self, msg)
        self.use_color = use_color

    def format(self, record):
        levelname = record.levelname
        if self.use_color and levelname in COLORS:
            levelname_color = COLOR_SEQ % (30 + COLORS[levelname]) + levelname + RESET_SEQ
            record.levelname = levelname_color
        return logging.Formatter.format(self, record)


# Custom logger class with multiple destinations
class ColoredLogger(logging.Logger):

    def __init__(self, name):
        logging.Logger.__init__(self, name, logging.WARNING)
        global DISPLAY_FORMAT
        self.console = None
        self.setFormat(DISPLAY_FORMAT)

    def setFormat(self, format):
        if self.console:
            self.removeHandler(self.console)

        color_formatter = ColoredFormatter(formatter_message(format, True))

        self.console = logging.StreamHandler()
        self.console.setFormatter(color_formatter)

        self.addHandler(self.console)


def init(verbosity=0, file_name=None, file_size=10, file_rotation=5, threading_display=False):
    global log_level, LOG_FORMAT
    log_format = LOG_FORMAT
    v_level = 0 if verbosity < 0 else 2 if verbosity > 2 else verbosity
    log_level = verbose_levels[v_level]
    if threading_display:
        display_format = "%(levelname)-1s (%(threadName)-10s) %(message)s"
        log_format = "%(asctime)s %(levelno)s %(threadName)-10s %(message)s"
        logger.setFormat(display_format)
    if file_name:
        LOG_SIZE = file_size * 1024 * 1024  # MB
        fh = logging.handlers.RotatingFileHandler(
            file_name, maxBytes=LOG_SIZE, backupCount=file_rotation)
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(log_format)
        fh.setFormatter(formatter)

        logging.getLogger('').addHandler(fh)

    logger.setLevel(level[log_level])


def create_logger(name, verbosity=0, file_name=None, file_size=10, file_rotation=5, threading_display=False):
    global log_level, LOG_FORMAT
    l = logging.getLogger(name)
    log_format = LOG_FORMAT
    v_level = 0 if verbosity < 0 else 2 if verbosity > 2 else verbosity
    log_level = verbose_levels[v_level]
    if threading_display:
        display_format = "%(levelname)-1s (%(threadName)-10s) %(message)s"
        log_format = "%(asctime)s %(levelno)s %(threadName)-10s %(message)s"
        l.setFormat(display_format)
    if file_name:
        LOG_SIZE = file_size * 1024 * 1024  # MB
        fh = logging.handlers.RotatingFileHandler(
            file_name, maxBytes=LOG_SIZE, backupCount=file_rotation)
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(log_format))
        l.addHandler(fh)
    l.setLevel(logging.DEBUG)
    return l

logging.setLoggerClass(ColoredLogger)
logger = logging.getLogger("escaux")

debug = logger.debug
info = logger.info
warning = logger.warning
error = logger.error
critical = logger.critical
