#!/usr/bin/env python
# coding: utf-8
from __future__ import absolute_import, division, print_function

from escauxlib import config, lib


class Smp:

    def __init__(self):
        self.smp_inventory = config.loader('/escaux/etc/smp_inventory.json')

    def find_smp_config(self, sopkey):
        # Compute range
        for _, smp_config in self.smp_inventory.items():
            r = smp_config['sopkey_range']
            if isinstance(r, list):
                continue
            l = []
            for g in r.split(','):
                if '-' in g:
                    start, stop = g.split('-', 2)
                    l += range(int(start), int(stop) + 1)
                else:
                    l.append(int(g))
            smp_config['sopkey_range'] = l

        # Find the config
        for _, smp_config in self.smp_inventory.items():
            if int(sopkey) in smp_config['sopkey_range']:
                return smp_config

        raise Exception('No SMP API URI found for sopkey {}'.format(sopkey))

    def get_web_url(self, sopkey):
        config = self.find_smp_config(sopkey)
        return "{root_url}/smp/{sopkey}/".format(
            root_url=config["url"]["web"],
            sopkey=lib.to_sopkey(sopkey)
        )
