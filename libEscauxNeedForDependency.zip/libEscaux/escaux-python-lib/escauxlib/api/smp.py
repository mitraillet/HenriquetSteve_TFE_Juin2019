#!/usr/bin/env python
# coding: utf-8
from __future__ import absolute_import, division, print_function

import json
import time

import requests

from escauxlib import lib, smp


class SmpAPI:

    def __init__(self, sopkey):
        self.sopkey = sopkey
        self.smp = smp.Smp()

    def __find_smp_config(self):
        return self.smp.find_smp_config(self.sopkey)

    def request(self, request, method='get', data=None):
        smp_config = self.__find_smp_config()
        response = requests.request(
            method=method,
            url='{0}/sop/{1}/{2}'.format(smp_config['url']['api'], lib.to_sopkey(self.sopkey), request),
            auth=tuple(smp_config['auth']),
            allow_redirects=True,
            verify=False,
            data=json.dumps(data),
            headers={
                'Content-Type': 'application/json'
            }
        )
        return response

    def get_extension(self, extension, context):
        r = self.request('dir/{}/{}'.format(context, extension))
        if r.status_code != 200:
            raise Exception("Error to get extension {}.{}".format(extension, context))
        return r.json()

    def set_extension(self, extension, context, data):
        r = self.request('dir/{}/{}'.format(context, extension))
        extension_exists = r.status_code == 200
        # Add new entry
        data["EXTENSION"] = extension
        data["CONTEXT"] = context
        if "SOP1" not in data:
            data["SOP1"] = lib.to_sopkey(self.sopkey)
        r = self.request('dir/{}/{}'.format(context, extension) if extension_exists else 'dir',
                         method='put' if extension_exists else 'post',
                         data=data)
        if r.status_code != 200:
            raise Exception("Set extension error HTTP {} - {}".format(r.status_code, r.json()))
        return r

    def remove_extension(self, extension, context):
        r = self.request('dir/{}/{}'.format(context, extension), method='delete')
        if r.status_code != 200:
            raise Exception("Extension {}.{} not removed".format(extension, context))

    def apply_change(self):
        r = self.request('commit', method='post')
        if r.status_code != 200:
            raise Exception("Apply changes error")
        # Waiting end
        for i in range(600):
            time.sleep(1)
            data = self.get_status_sops()
            if [sop for sop in data['sops'] if sop['action'] != 'nothing']:
                continue
            if sum([int(sop['err_count']) for sop in data['sops']]) > 0:
                raise Exception(
                    "Apply changes error: {}".format(sum([int(sop['error_count']) for sop in data['sops']])))
            return
        raise Exception("Apply changes timeout !")

    def assign_sop(self, fields):
        r = self.request('assignSopKey', method='put', data=fields)
        if r.status_code != 200:
            raise Exception("Error to assign SOP: {}".format(r))

    def info(self):
        r = self.request('info')
        if r.status_code != 200:
            raise Exception("Error to get info: {}".format(r))
        return r.json()

    def install_module(self, list=None):
        r = self.request('installModule', method='put', data=list)
        if r.status_code != 200:
            raise Exception("Error to install module SOP: {}".format(r))
        # Waiting end
        while True:
            time.sleep(1)
            data = self.get_status_sops()
            if [sop for sop in data['sops'] if sop['action'] != 'nothing']:
                continue
            if sum([int(sop['err_count']) for sop in data['sops'] if sop['sopkey'] == self.sopkey]) > 0:
                raise Exception("Install module error: {}".format(
                    sum([int(sop['err_count']) for sop in data['sops'] if sop['sopkey'] == self.sopkey])))
            return

    def get_status_sops(self):
        r = self.request('getStatusMultiSop', 'get')
        return r.json()

    def enable_service(self, backup=None, monitoring=None):
        # Backup service
        if backup is not None:
            r = self.request('services/backup', method='post' if backup else 'delete')
            if r.status_code != 200:
                raise Exception("Error to change backup service: {}".format(r))
        # Monitoring service
        if monitoring is not None:
            r = self.request('services/monitoring', method='post' if monitoring else 'delete')
            if r.status_code != 200:
                raise Exception("Error to change monitoring service: {}".format(r))
        # Get status
        r = self.request('services', method='get')
        if r.status_code != 200:
            raise Exception("Error to get service state: {}".format(r))
        return r.json()
