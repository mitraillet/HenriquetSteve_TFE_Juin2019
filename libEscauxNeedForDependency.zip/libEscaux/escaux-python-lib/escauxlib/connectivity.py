#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

import base64
import os
import subprocess
import uuid

import paramiko

from escauxlib import log


class Connection:
    def __init__(self, host, username=None, key_filename=None):
        self.host = host
        self.username = username
        self.private_key = paramiko.RSAKey.from_private_key_file(key_filename) if key_filename else None

    def open_ssh_connexion(self):
        self.connection = paramiko.SSHClient()
        self.connection.load_system_host_keys()
        self.connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.connection.connect(self.host, port=22, username=self.username, pkey=self.private_key, timeout=10)
        session = self.connection.get_transport().open_session()
        paramiko.agent.AgentRequestHandler(session)
        self.transport = self.connection.open_sftp()

    def close_ssh_connexion(self):
        self.transport.close()
        self.connection.close()
        del self.connection
        del self.transport


class Transfer:
    def __init__(self, conn):
        self.sftp = conn

    def get(self, remote_path, local_path):
        self.sftp.get(remote_path, local_path)

    def put(self, local_path, remote_path):
        self.sftp.put(local_path, remote_path)


class Script:
    def __init__(self, connection, exe_remote=True, code="", interpret="sh", sudo=False,
                 ignore_error=False):
        self.connection = connection
        self.interpret = interpret
        self.exe_remote = exe_remote
        self.code = code
        self.args = {}
        self.file_name = None
        self.sudo = sudo
        self.ignore_error = ignore_error

    def __iadd__(self, other):
        self.code += other + "\n"
        return self

    def file(self, path):
        self.file_name = path

    def exe(self):
        # TODO fast remote execution (one line). Don't use remote transfer in tmp script

        # Define script name
        path_script = '/tmp/escaux_script_{0!s}'.format(base64.b32encode(uuid.uuid4().bytes)[:26])

        # Create local script file
        if not self.file_name:
            f = open(path_script, 'w')
            f.write(self.code)
            f.close()

        chan = None
        # Transfer script to remote server if needed
        if self.exe_remote:
            self.connection.open_ssh_connexion()
            chan = self.connection.connection.get_transport().open_session()
            t = Transfer(self.connection.transport)
            t.put(self.file_name if self.file_name else path_script, path_script)

        # Script execution
        cmd = '{sudo}{interpret} {script} {args}'.format(
            sudo=("sudo " if self.sudo else ""),
            interpret=self.interpret,
            script=path_script,
            args=" ".join([("-" if len(str(arg)) == 1 else "--") + str(arg) + " " + str(val) for arg, val in
                           self.args.iteritems()]))

        log.debug("{1} code execution: {0:.100}".format(self.code, "Remote" if self.exe_remote else "Local"))
        log.debug("Launch {1} command: {0}".format(cmd, "remote" if self.exe_remote else "local"))

        if self.exe_remote:
            # Remote execution
            chan.exec_command(cmd)
            stdout = chan.makefile('r', -1)
            stderr = chan.makefile_stderr('r', -1)
            self.err = stderr.read()
            self.out = stdout.read()
            return_code = chan.recv_exit_status()
        else:
            # Local execution
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            self.out, self.err = p.communicate()
            return_code = p.returncode

        # Remove script
        os.remove(path_script)
        if self.exe_remote:
            self.connection.connection.exec_command("rm -rf {}".format(path_script))

        # Close remote connection
        if self.exe_remote:
            self.connection.close_ssh_connexion()

        # Error handler
        if return_code != 0 and not self.ignore_error:
            raise Exception(
                '{1} script execution error: {0}'.format(self.err, "Remote" if self.exe_remote else "Local"))

        return self.out

    @staticmethod
    def remote_exe(connect, cmd=None, filename=None, ignore_err=False, sudo=False):
        script = Script(connect, code=cmd, exe_remote=True, ignore_error=ignore_err, sudo=sudo)
        if filename:
            script.file(filename)
        return script.exe()
