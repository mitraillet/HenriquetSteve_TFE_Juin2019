#!/usr/bin/env python
# coding: utf-8
from __future__ import absolute_import, division, print_function


def to_sopkey(string):
    """ Convert a hostname into a SOP key.
    '12345.sop.escaux.com' will become '00012345'
    :param string: Hostname.
    """
    return str(string).split('.')[0].zfill(8)
