#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

import re
import time

import ipcalc

from escauxlib import config
from escauxlib import connectivity
from escauxlib import log
from escauxlib.api.smp import SmpAPI


class Sop:
    def __init__(self, sopkey, host=None):
        self.sopkey = int(sopkey)
        self.hostname = str(self.sopkey) + ".sop.escaux.com"
        self.ssh_connection = None
        self.ip = None
        self.config = dict()
        self.host = None
        self.host_id = None
        self.master = None
        if host:
            self.host = Sop(host['sopkey'])
            self.host_id = host['id']

    def cmd(self, cmd, sudo=False):
        """
        Execute a bash command line on remote SOP

        :param cmd: Bash command line
        :param sudo: Run the script in sudo
        :return: the stdout of the command
        """
        if not self.ssh_connection:
            self.ssh_connection = connectivity.Connection(
                self.hostname,
                config.config["ssh"]["username"],
                config.config["ssh"]["pkey"]
            )
        return connectivity.Script.remote_exe(self.ssh_connection, cmd, sudo=sudo)

    def master_sopkey(self):
        """
        Get the master SOPKEY of the SOP inside the SMP clustering

        Note: if the SOP is not in a cluster the master SOPKEY will be the same SOPKEY

        :return: Master SOPKEY
        """
        if self.master:
            return self.master
        api = SmpAPI(self.sopkey)
        info = api.info()
        self.master = info['master'] if 'master' in info else self.sopkey
        return self.master

    def get_ip(self):
        """
        Get the IPv4 address of the SOP

        :return: mapping between interface and the IP address
        """
        if self.ip:
            return self.ip
        # TODO use framework
        ip_cmd_stdout = self.cmd("ip addr show")
        list = re.compile("[0-9]+: ([a-zA-Z0-9]+):.*\n.*\n*\s+inet ([0-9.]+)").findall(ip_cmd_stdout)
        self.ip = {inter: ip for inter, ip in list}
        return self.ip

    def get_route(self):
        """
        List all IPv4 route

        :return: Mapping between of the netmask and a dictionary of outgoing gateway and interface
        """
        try:
            ip_route_cmd = self.cmd("ip route show", sudo=True)
        except:
            return dict()
        route_list = dict()
        vals = re.compile("([a-zA-Z0-9.\/]+)\s*via\s*([0-9.]+)\s*dev\s*([a-z0-9]+)").findall(ip_route_cmd)
        route_list = {(ipcalc.Network(ip) if ip != "default" else "default"): dict(
            gateway=gateway,
            interface=interface
        ) for ip, gateway, interface in vals}
        return route_list

    def set_interface(self, interface, status):
        """
        Set an interface of the SOP up or down

        :param interface: Network interface
        :param status: 'up' or 'down
        """
        if status != "up" and status != 'down':
            return
        self.cmd("ip link set dev %s %s" % (interface, status), sudo=True)

    def __waiting_host(self, state, max_try=180):
        """
        Waiting that the vSOP is in a state

        :param state: State that we required
        :param max_try: Max time before to declare the state not reachable
        :return: True if the vSOP is the state specified otherwise False
        """
        # Pooling status command
        for i in range(0, max_try):
            out = self.host.cmd('/escaux/bin/vsop status %s' % self.host_id, sudo=True)
            if state in out:
                return True
            time.sleep(1)
        return False

    def halt(self, waiting=False):
        """
        Halt the SOP.
        If it's a vSOP, the SOP is shutdown via the vSOP Host otherwise the SOP is shutdown.

        :param waiting: Waiting the end of the halt process
        """
        if self.host:
            log.debug("Halt SOP {} on host {} ({})".format(self.sopkey, self.host.sopkey, self.host_id))
            out = self.host.cmd('/escaux/bin/vsop status %s' % self.host_id, sudo=True)
            if "RUNNING" not in out:
                log.debug("Try to halt a no running vSOP {}".format(self.host_id))
                return
            self.host.cmd('/escaux/bin/vsop stop %s' % self.host_id, sudo=True)
            if waiting and not self.__waiting_host("INSTALLED"):
                raise Exception("The server is not turned off")
        else:
            log.debug("Halt SOP {}".format(self.sopkey))
            connectivity.Script.remote_exe(self.ssh_connection, 'shutdown -h now')

    # TODO waiting

    def start(self, waiting=False):
        """
        Start the SOP

        :param waiting: Waiting the end of the start process
        """
        if self.host:
            log.debug("Staring SOP {} on host {}".format(self.sopkey, self.host.sopkey))
            self.host.cmd('/escaux/bin/vsop start %s' % self.host_id, sudo=True)
            if waiting and not self.__waiting_host("RUNNING"):
                raise Exception("The server hasn't started")
        else:
            # TODO
            pass

    def baseline(self):
        """
        Get the baseline version.

        :return: baseline of version with major, minor, revision, build, version
        """
        host = self if not self.host else self.host
        cmd = "cat {}/escaux/etc/version".format("" if not self.host else "/data/lxc/{}/rootfs/".format(self.host_id))
        version = host.cmd(cmd, sudo=True)
        v = re.compile(r'(\d+).(\d+).(\d+).?(\w*)').findall(version)
        return dict(
            major=int(v[0][0]),
            minor=int(v[0][1]),
            revision=int(v[0][2]),
            build=v[0][3],
            version=version
        )

    def compute_vsop(self):
        """
        Compute the vSOP information for the SMP

        """

        api = SmpAPI(self.sopkey)
        info = api.info()
        self.host = Sop(info['host'])
        self.host_id = info['host_resource']

    def vsop_export(self, path):
        """
        Export the vSOP.

        Note: ionice is used to not have impact on the host

        :param path: Path to the export on vSOP Host
        """
        if self.host:
            log.debug("Exporting {} to {}".format(self.host_id, path))
            self.host.cmd('/usr/bin/ionice -c 3 /escaux/bin/vsop export {} {}'.format(self.host_id, path), sudo=True)

    def vsop_import(self, path):
        """
        Import a vSOP.

        :param path: Path where the import file is located on vSOP Host
        """
        if self.host:
            log.debug("Importing {} from {}".format(self.host_id, path))
            self.host.cmd('/escaux/bin/vsop import {}'.format(path), sudo=True)

    def vsop_info(self):
        """
        Get vSOP information of the SOP.

        :return: ID, State, SOPKEY and Description
        """
        if self.host:
            d = self.host.cmd('/escaux/bin/vsop status {}'.format(self.host_id), sudo=True)
            list = re.compile(r"(\w+)\s+([A-Z]+)\s+([0-9]+).*\((.*)\)").findall(d)
            return dict(
                id=list[0][0],
                state=list[0][1],
                sopkey=list[0][2],
                description=list[0][3]
            )

    def net_br(self):
        """
        Get the bridging between the vSOP guest of the host.

        :return: List of dict of configuration type and vLAN
        """
        if self.host:
            data = self.host.cmd("cat /data/lxc/{}/config".format(self.host_id), sudo=True)
            return [dict(config=c, vlan=vlan) for c, vlan in
                    re.compile("lxc.network.link\s+=\s+([a-z0-9]+).?([0-9]*)").findall(data)]
