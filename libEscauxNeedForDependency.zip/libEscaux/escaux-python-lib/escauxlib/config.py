#!/usr/bin/env python
# coding: utf-8

from __future__ import absolute_import, division, print_function

config = dict()


def load(path):
    """
    Load the file configuration. The result is stored in the config variable. This function can decode json and yaml
    files.

    :param path: Path to the configuration file
    :return:
    """
    global config
    config = loader(path)


def loader(path, order=False):
    """
    Load the file configuration. The result of the content is return in dict format. This function can decode json and
    yaml files.

    :param path:	Path to the configuration file
    :return: 		Content of the configuration file
    """
    data = None
    f = open(path)
    if path.endswith(".json"):
        import json
        data = json.load(f)
    elif path.endswith(".yml") or path.endswith(".yaml"):
        if order:
            import oyaml as yaml
        else:
            import yaml
        data = yaml.load(f)
    f.close()
    return data


def save(path):
    """
    Save current file configuration.

    :param path:    Path to the configuration file
    """
    global config
    saver(config, path)


def saver(data, path, format=None):
    """
    Save the file configuration to specific place.

    :param data:    Content of the configuration file
    :param path:    Path to the configuration file
    :param format:  Type of output format: json or yaml
    """
    f = open(path, 'w')
    if path.endswith(".json") or format is 'json':
        import json
        json.dump(data, f, indent=4, sort_keys=True)
    elif path.endswith(".yml") or path.endswith(".yaml") or format is 'yaml':
        import yaml
        yaml.safe_dump(data, f, default_flow_style=False)
    f.close()
